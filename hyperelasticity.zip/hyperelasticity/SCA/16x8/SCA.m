pretensor;
areas_all = sum(areas);
d = d1 + d2 ;                   % ��cluster����Ŀ

% ��para����¼����cluster�Ĳ���
para = zeros(d,2);
for i = 1:d
    if i <= d1
        para(i,:) = [K1,mu1];
    else
        para(i,:) = [K2,mu2];
    end
end

% ��ʼ��1.(a)
F = zeros(3,3,d);        % d��ʾ�ڼ���cluster�ı����ݶ�
for i = 1:d
    F(:,:,i) = eye(3,3);
end 
P = zeros(3,3,d);  P_total = zeros(3,3,d);
dF = zeros(3,3,d);

% ��ʼ��1.(b)
% ��ʼ������cluster�����߸նȣ�����ʼ���ο����ϵĸն�C0
K4 = zeros(3,3,3,3,d); 
C0_ = zeros(3,3,3,3);
for i = 1:d
    K4(:,:,:,:,i) = para(i,1) * II + 2 * para(i,2) * (I4s - 1./3. * II); 
    C0_ = C0_ + areas(i) / areas_all * K4(:,:,:,:,i);
end
C0 = matrix4_matrix2(C0_);
% ��ʼ���ο����ϵ�lame����
J = 1/3 * II; K = I4 - J;
C_J = C0 .* matrix4_matrix2(J) ; C_K = C0 .* matrix4_matrix2(K);
lambda0 = 1/3 * ( sum( C_J(:) ) - 1/8 * sum( C_K(:) ) );
mu0 = 1/16 * sum( C_K(:) );

F_com = zeros(ninc,9); P_com = zeros(ninc,9);
F0_t = eye(3,3);
for xx = 1:ninc
    disp(['xx=',num2str(xx)]);
    F0 = eye(3,3);  
    F0(1,1) = F0(1,1) + xx/ninc * epsilon_max;
    F0(2,2) = F0(2,2) + xx/ninc * epsilon_max;
    % ÿ��cluster��dF��ʼ�� 
    dF0 = F0 - F0_t;
    for yy = 1:d
        dF(:,:,yy) = dF0;
    end
    while true
        % ��������
        
        F_new = F + dF; 
        dF_new = dF;
%         P_new = P;
        
        D = 1/2/mu0 * D1 -  lambda0/2/mu0/(lambda0+2*mu0) * D2;
        C0_ = lambda0 * II + 2 * mu0 * I4 ;
        C0 = matrix4_matrix2(C0_);
        step = 1;
        while true
            disp(['step=',num2str(step)]);
            step = step + 1;
            A = zeros(9*d,9*d);  % ����ģ������
            P_C0 = zeros(9,d);           % �洢 dPj - C0:dFj
            K_C0 = zeros(9,9,d);         % �洢 K4 - C0
            
            r = zeros(9*d,1);     % ������������ʩ�¸񷽳̵�ʣ�ಿ�ֵĳ�ʼ��
            
            dP_new = zeros(3,3,d);   
            for k = 1:d
                [P_total(:,:,k), K4(:,:,:,:,k)] = constitutive(F_new(:,:,k), para(k,1), para(k,2));
                dP_new(:,:,k) = P_total(:,:,k) - P(:,:,k); 
                P_C0(:,k) = matrix2_vector(dP_new(:,:,k)) - C0 *  matrix2_vector(dF_new(:,:,k));   %%%%%%%5555555
                K_C0(:,:,k) = matrix4_matrix2(K4(:,:,:,:,k)) - C0;
               
            end
            
            
            %     F �ķ���
            for i = 1:d
                A((i*9-8):(i*9),(i*9-8):(i*9)) = A((i*9-8):(i*9),(i*9-8):(i*9)) + eye(9,9); % FI �ĵ���
                
                % ����ʩ�¸񷽳̵�ʣ�ಿ�ֺ͵�������
                r((i*9-8):(i*9),1) = matrix2_vector(dF_new(:,:,i)) - matrix2_vector(dF0);
                for kk = 1:d
                    r((i*9-8):(i*9),1) = r((i*9-8):(i*9),1) + D(:,:,i,kk) * P_C0(:,kk);
                    A((i*9-8):(i*9),(kk*9-8):(kk*9)) =  A((i*9-8):(i*9),(kk*9-8):(kk*9)) + D(:,:,i,kk) * K_C0(:,:,kk);
                end
            end
            
            detla_f = - inv(A) * r ;
            if max(abs(detla_f)) < 1e-6
                break;
            end
            dF_new = dF_new + vector_matrix3( detla_f(1:(d*9),1) ,d);
            F_new = F + dF_new; 
            
           
        end
        
        [lambda_opt,mu_opt] = update_incremental_lam_mu(areas,A,K4,d);
        if abs(lambda_opt-lambda0)/lambda0 < 10^(-3) && abs(mu_opt-mu0)/mu0 < 10^(-3)
            lambda0 = lambda_opt; mu0 = mu_opt;
            F = F_new;
%             dF = dF_new; 
            P  = P_total;            
            break;
        else
            lambda0 = lambda_opt; mu0 = mu_opt;
            
        end
        
    end
   
    % ����ʹ�õ���homogenization_P��������homogenization
    [P_hom, F_hom] = homogenization(P,F,areas);
    F_com(xx,:) = reshape( F_hom, 1, 9);
    P_com(xx,:) = reshape( P_hom, 1, 9);   
    
    F0_t = F0;
    
end