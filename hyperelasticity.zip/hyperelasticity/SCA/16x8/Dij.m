function [D1,D2] = Dij(kk1,kk2,areas) 
% ----------------------------------------------
global N1 N2 N3 d1 d2
d = d1 + d2;
N = [N1,N2,N3];

% -----------------------------------------------
% chi�ĵ�������cluster�ķ���ͼ������N1*N2*N3
cluster_map = zeros(N1,N2,N3);
len1 = length(kk1); len2 = length(kk2);
for i = 1:len1
    cluster_map(kk1(i,2),kk1(i,3),kk1(i,4)) = kk1(i,1);
end
for j = 1:len2
    cluster_map(kk2(j,2),kk2(j,3),kk2(j,4)) = kk2(j,1) + d1;         
end
disp('cluster_map is done!');

% -----------------------------------------------
% �໥���������ĵ�һ���ֺ͵ڶ�����(����Ҷ�任֮��Ŀռ�)
gramma_1 = zeros(N1,N2,N3,3,3,3,3);
gramma_2 = zeros(N1,N2,N3,3,3,3,3);
for n = 1:N1
    n1 = n;
    if n1 > floor(N1/2+1)
        n1 = n1 - N1;
    end
    for p = 1:N2
        p1 = p;
        if p1 > floor(N2/2+1)
            p1 = p1 - N2;
        end
        for q = 1:N3
            q1 = q;
            if q1 > floor(N3/2+1)
                q1 = q1 - N3;
            end
            npq = [n1,p1,q1];
            if n == 1 && p == 1 && q == 1
                gramma_1(n,p,q,:,:,:,:) = 0;
                gramma_2(n,p,q,:,:,:,:) = 0;
                continue;
            end
            for i = 1:3
                for j = 1:3
                    for k = 1:3
                        for m = 1:3
                            gramma_1(n,p,q,i,j,k,m) = (i==k) * xi( N(j), npq(j)) * xi(N(m),npq(m)) ...
                                / (xi(N1,npq(1))^2 + xi(N2,npq(2))^2 + xi(N3,npq(3))^2);
                            gramma_2(n,p,q,i,j,k,m) = xi(N(i), npq(i)) * xi(N(j), npq(j)) * ...
                                xi(N(k), npq(k)) * xi(N(m), npq(m)) / (xi(N1,npq(1))^2 + xi(N2,npq(2))^2 + xi(N3,npq(3))^2)^2 ;
                        end
                    end
                end
            end
        end
    end
end

disp('the gramma_s fourier transformation is done!');

% -----------------------------------------------------
% ���D1��D2����Ϊdxdx3x3x3x3��������
D1_tensor = zeros(3,3,3,3,d,d); D2_tensor = zeros(3,3,3,3,d,d);
for I = 1:d
    chi_I = cluster_map;
    chi_I(chi_I ~= I) = 0;
    chi_I(chi_I == I) = 1;
    for J = I:d
        chi_J = cluster_map;
        chi_J(chi_J ~= J) = 0;
        chi_J(chi_J == J) = 1;
        fftn_chi_J = fftn(chi_J);
        for i = 1:3
            for j = 1:3
                for k = 1:3
                    for m = 1:3
%                         % ���ά�Ȳ�һ�µ�����
                        D1_tensor(i,j,k,m,I,J) =  sum( sum( sum (chi_I .* ifftn(gramma_1(:,:,:,i,j,k,m) .* fftn_chi_J) ) ) ) / areas(I);
                        D2_tensor(i,j,k,m,I,J) =  sum( sum( sum (chi_I .* ifftn(gramma_2(:,:,:,i,j,k,m) .* fftn_chi_J) ) ) ) / areas(I);
                    end
                end
            end
        end
    end
end
for I = 2:d
    for J = 1:(I-1)
        D1_tensor(:,:,:,:,I,J) = areas(J) / areas(I) * D1_tensor(:,:,:,:,J,I);
        D2_tensor(:,:,:,:,I,J) = areas(J) / areas(I) * D2_tensor(:,:,:,:,J,I);
    end
end
disp('the tensor D1 and D2 are done!');

% ---------------------------------------------------------------
% ������D1��D2����СΪdxdx3x3x3x3��ת��Ϊ���󣨴�СΪdxdx9x9��
D1 = zeros(9,9,d,d); D2 = zeros(9,9,d,d);
for I = 1:d
    for J = 1:d
        D1(:,:,I,J) = real(matrix4_matrix2(D1_tensor(:,:,:,:,I,J)));
        D2(:,:,I,J) = real(matrix4_matrix2(D2_tensor(:,:,:,:,I,J)));
    end
end
disp('the matrix D1 and D2 are done!');
end

function [m] = xi(x,y)
m = (y-1)/x * 2 * pi;
end