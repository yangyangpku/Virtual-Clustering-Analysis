function [a] = vector_matrix2(b)
a = [b(1),b(4),b(7);b(2),b(5),b(8);b(3),b(6),b(9)];

end
