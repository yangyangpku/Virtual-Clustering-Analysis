%  aa = csvread('csv_2.csv'); bb = csvread('csv_P.csv');
%  len = length(aa);
%  sum_DNSF = zeros(3,3); sum_DNSP = zeros(3,3); 
 sum_SCAF = zeros(3,3); sum_SCAP = zeros(3,3);
%  for i = 1:len
%      sum_DNSF = sum_DNSF + reshape( aa(i,4:12),3,3)';
%      sum_DNSP = sum_DNSP + reshape( bb(i,4:12),3,3)';
%  end
%  sum_DNSF = sum_DNSF / len;sum_DNSP = sum_DNSP / len;
 for i = 1:(d1+d2)
     sum_SCAF = sum_SCAF + areas(i)/ areas_all * F(:,:,i);
     sum_SCAP = sum_SCAP + areas(i)/ areas_all * P(:,:,i);
 end
 