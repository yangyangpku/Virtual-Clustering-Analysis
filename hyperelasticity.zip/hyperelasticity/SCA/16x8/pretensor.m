% ���� identity tensor �Ķ���
% ����������֮ǰ��������
global I I4 I4rt I4s II

% -------------------------------------------------
I = zeros(3,3);
for i = 1:3
    for j = 1:3
        I(i,j) = i == j;
    end
end
% -------------------------------------------------
I4rt = zeros(3,3,3,3);
for i=1:3
    for j=1:3
        for k=1:3
            for m=1:3
                I4rt(i,j,k,m) = ( i == m) && ( j == k);
            end
        end
    end
end
% -------------------------------------------------
I4 = zeros(3,3,3,3);
for i=1:3
    for j=1:3
        for k=1:3
            for m=1:3
                I4(i,j,k,m) = ( i == k) && ( j == m );
            end
        end
    end
end
% -------------------------------------------------
I4s = (I4 + I4rt)/2;
II = dyad22(I,I);
clear i j k m;
