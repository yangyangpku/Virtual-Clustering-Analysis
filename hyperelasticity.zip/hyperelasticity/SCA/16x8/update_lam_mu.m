function [lambda,mu] = update_lam_mu(P,F,areas)
% P,F�ֱ�Ϊ���Ȼ��ĵ�һp-kӦ���ͱ����ݶ�  
len = length(areas);
P_hom = tensor(zeros(3,3)); F_hom = tensor(zeros(3,3));
for i = 1:len
    P_hom = P_hom + areas(i) / sum(areas) * P(:,:,i);
    F_hom = F_hom + areas(i) / sum(areas) * F(:,:,i);
end
global I
epsilon = 0.5 * ( trans2(F_hom) + F_hom - I);
A = zeros(2,2); b = zeros(2,1);
tr_eps = epsilon(1,1) + epsilon(2,2) + epsilon(3,3);
A(1,1) = 3 * tr_eps;
A(1,2) = 2 * tr_eps;
A(2,1) = tr_eps * tr_eps;
A(2,2) = 2 * ddot22(epsilon, epsilon);
b(1,1) = P_hom(1,1) + P_hom(2,2) + P_hom(3,3);
b(2,1) = ddot22(P_hom, epsilon);
para = A\b;
lambda = para(1); mu = para(2);
end