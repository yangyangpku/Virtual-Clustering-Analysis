function [z] = distance(x,y)

a = x .^ 2; 
b = y .^ 2;
z = sum(a(:)) / sum(b(:));
