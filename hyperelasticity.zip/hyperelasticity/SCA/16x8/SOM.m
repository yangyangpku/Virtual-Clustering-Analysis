% data_select;
function [kk,S] = SOM(k0,d) 
kk = k0(:,4:12);   % �Եڼ����ֽ��о���
[len,~] = size(kk);
d_row = 1;  d_col = d;  % �У���
pos=zeros(2,d);
for j=1:d
    pos(2,j)=fix((j-1)/d_col)+1;%y����
    pos(1,j)=mod(j-1,d_col)+1;%x����
end

integer = randi([1,len], 1, d);
cluster_weight = kk(integer, :);
distance = zeros(d,1);
T=1000000;
sigma0=max(d_row,d_col);

for t=0:T
    yita=0.1*exp(-3/T*t);
    num=fix(rand()*len)+1;
%     for num=1:n
    for j=1:d
        distance(j)=sum((cluster_weight(j,:)- kk(num,:)).^2);
    end
    [~,j_min]=min(distance);
    sigma=sigma0*exp(-t/(T/3/log(sigma0)));
    up=max(round(pos(2,j_min)-sigma*3),1);
    down=min(round(pos(2,j_min)+sigma*3),d_row);
    left=max(round(pos(1,j_min)-sigma*3),1);
    right=min(round(pos(1,j_min)+sigma*3),d_col);
    for j=up:down
        for k=left:right
            topo_distant=max(abs(j-pos(2,j_min)),abs(k-pos(1,j_min)));
            h=exp(-topo_distant^2/2/sigma^2);
            cluster_weight(j*d_col-d_col+k,:)=cluster_weight(j*d_col-d_col+k,:)+yita*h*(kk(num,:)-cluster_weight(j*d_col-d_col+k,:));
        end
    end
end

index = zeros(1,len);
S = zeros(1,d);
for num = 1:len
    for j = 1:d
        distance(j) = sum((cluster_weight(j,:)-kk(num,:)).^2);
    end
    [~,j_min]=min(distance);
    index(num)=j_min;
    S(j_min) = S(j_min) + 1;
end
kk = [index', k0];
        