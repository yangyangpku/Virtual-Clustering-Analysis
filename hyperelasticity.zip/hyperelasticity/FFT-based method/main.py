# -*- coding:utf-8 -*-

# hyper-elasticity , finite deformation

import numpy as np
import scipy.sparse.linalg as sp
import itertools
import csv

# ----------------------------------- GRID ------------------------------------

ndim   = 3   # number of dimensions
N      = 31  # number of voxels (assumed equal for all directions)

# ---------------------- PROJECTION, TENSORS, OPERATIONS ----------------------

# tensor operations/products: np.einsum enables index notation, avoiding loops
# e.g. ddot42 performs $C_ij = A_ijkl B_lk$ for the entire grid
trans2 = lambda A2   : np.einsum('ijxyz          ->jixyz  ',A2   )
ddot42 = lambda A4,B2: np.einsum('ijklxyz,lkxyz  ->ijxyz  ',A4,B2)
ddot44 = lambda A4,B4: np.einsum('ijklxyz,lkmnxyz->ijmnxyz',A4,B4)
dot22  = lambda A2,B2: np.einsum('ijxyz  ,jkxyz  ->ikxyz  ',A2,B2)
dot24  = lambda A2,B4: np.einsum('ijxyz  ,jkmnxyz->ikmnxyz',A2,B4)
dot42  = lambda A4,B2: np.einsum('ijklxyz,lmxyz  ->ijkmxyz',A4,B2)
dyad22 = lambda A2,B2: np.einsum('ijxyz  ,klxyz  ->ijklxyz',A2,B2)

# identity tensor                                               [single tensor]
i      = np.eye(ndim)
# identity tensors                                            [grid of tensors]
I      = np.einsum('ij,xyz'           ,                  i   ,np.ones([N,N,N]))
I4     = np.einsum('ijkl,xyz->ijklxyz ',np.einsum('il,jk',i,i),np.ones([N,N,N]))
I4rt   = np.einsum('ijkl,xyz->ijklxyz',np.einsum('ik,jl',i,i),np.ones([N,N,N]))
I4s    = (I4+I4rt)/2.
II     = dyad22(I,I)

# projection operator                                         [grid of tensors]
# NB can be vectorized (faster, less readable), see: "elasto-plasticity.py"
# - support function / look-up list / zero initialize
delta  = lambda i,j: np.float(i==j)            # Dirac delta function
freq   = np.arange(-(N-1)/2.,+(N+1)/2.)        # coordinate axis -> freq. axis
Ghat4  = np.zeros([ndim,ndim,ndim,ndim,N,N,N]) # zero initialize
# - compute
for i,j,l,m in itertools.product(range(ndim),repeat=4):
    for x,y,z    in itertools.product(range(N),   repeat=3):
        q = np.array([freq[x], freq[y], freq[z]])  # frequency vector
        if not q.dot(q) == 0:                      # zero freq. -> mean
            Ghat4[i,j,l,m,x,y,z] = delta(i,m)*q[j]*q[l]/(q.dot(q))

# (inverse) Fourier transform (for each tensor component in each direction)
fft    = lambda x  : np.fft.fftshift(np.fft.fftn (np.fft.ifftshift(x),[N,N,N]))
ifft   = lambda x  : np.fft.fftshift(np.fft.ifftn(np.fft.ifftshift(x),[N,N,N]))

# functions for the projection 'G', and the product 'G : K^LT : (delta F)^T'
G      = lambda A2 : np.real( ifft( ddot42(Ghat4,fft(A2)) ) ).reshape(-1)
K_dF   = lambda dFm: trans2(ddot42(K4,trans2(dFm.reshape(ndim,ndim,N,N,N))))
G_K_dF = lambda dFm: G(K_dF(dFm))

# ------------------- PROBLEM DEFINITION / CONSTITIVE MODEL -------------------

# phase indicator: cubical inclusion of volume fraction (9**3)/(31**3)
phase  = np.zeros([N,N,N]); 
inc_d = 23
radius2 = (inc_d - 1)**2 /4           
center = (N - 1) / 2              
for ii,j,k in itertools.product(range(N),  repeat=3):
    if ((ii-center)**2 + (j-center)**2 + (k-center)**2) <= radius2:
        phase[ii, j, k] = 1
                
# material parameters + function to convert to grid of scalars
param  = lambda M0,M1: M0*np.ones([N,N,N])*(1.-phase)+M1*np.ones([N,N,N])*phase

E1     = 70   ;     v1 = 0.33   ;
E2     = 400  ;     v2 = 0.2  ;
K1     = E1/3/(1-2*v1);  mu1    = E1/2/(1+v1);   
K2     = E2/3/(1-2*v2);  mu2    = E2/2/(1+v2);   

K      = param(K1,K2)  # bulk  modulus                   [grid of scalars]
mu     = param(mu1,mu2)  # shear modulus                   [grid of scalars]

# constitutive model: grid of "F" -> grid of "P", "K4"        [grid of tensors]
def constitutive(F):
    C4 = K*II+2.*mu*(I4s-1./3.*II)
    S  = ddot42(C4,.5*(dot22(trans2(F),F)-I))
    P  = dot22(F,S)
    K4 = dot24(S,I4)+ddot44(ddot44(I4rt,dot42(dot24(F,C4),trans2(F))),I4rt)
    return P,K4

# ----------------------------- LOADING -----------------------------

# initialize deformation gradient, and stress/stiffness       [grid of tensors]
F     = np.array(I,copy=True)
P     = np.zeros([3,3,N,N,N])

# initialize macroscopic incremental loading
ninc = 300
lam = 0.0
barF = np.array(I,copy=True)
barF_t = np.array(I,copy=True)
F_record = np.zeros((ninc,9))
P_record = np.zeros((ninc,9))

# # set macroscopic loading
# DbarF = np.zeros([ndim,ndim,N,N,N]); DbarF[0,0] += 0.2; DbarF[1,1] += 0.2;

# initial tangent operator: the elastic tangent
K4    = K*II+2.*mu*(I4s-1./3.*II)

# incremental deformation
for inc in range(0,ninc):
    print('=============================')
    print('inc: {0:d}'.format(inc))
    
    # set macroscopic deformation gradient
    lam      += 0.15/float(ninc)
    barF      = np.array(I,copy=True)
    barF[0,0] = 1. + lam
    barF[1,1] = 1. + lam
    
    # store normalization
    Fn = np.linalg.norm(F)
    
    # first iteration residual: distribute "barF" over grid using "K4"
    b     = -G_K_dF(barF-barF_t)
    F    +=         barF-barF_t
    
    # parameters for Newton iterations: normalization and iteration counter
    Fn    = np.linalg.norm(F)
    iiter = 0
    
    # iterate as long as the iterative update does not vanish
    while True:
        # solve linear system using the Conjugate Gradient iterative solver
        dFm,_ = sp.cg(tol=1.e-8,
          A   = sp.LinearOperator(shape=(F.size,F.size),matvec=G_K_dF,dtype='float'),
          b   = b,
        )
        
        # add solution of linear system to DOFs
        F += dFm.reshape(3,3,N,N,N)
        
        # compute residual stress and tangent, convert to residual
        P,K4  = constitutive(F)
        b     = -G(P) 
        
        # check for convergence, print convergence info to screen
        print('{0:10.2e}'.format(np.linalg.norm(dFm)/Fn))
        if np.linalg.norm(dFm)/Fn<1.e-3 and iiter>0: break
        
        # update Newton iteration counter
        iiter += 1
    
    barF_t = np.array(barF,copy=True)
    
    F_record[inc,:] = np.sum(F, axis = (2,3,4)).reshape(1,9) / N /N /N
    P_record[inc,:] = np.sum(P, axis = (2,3,4)).reshape(1,9) / N /N /N
    
    if inc == 0:
        out1 = open('cluster_hy_F.csv','a',newline='')
        out2 = open('cluster_hy_P.csv','a',newline='')
        csv_write1 = csv.writer(out1,dialect='excel')
        csv_write2 = csv.writer(out2,dialect='excel')
        for ii in range(N):
            for j in range(N):
                for k in range(N):
                    vec1 = np.append([ii+1,j+1,k+1],F[:,:,ii,j,k].reshape(-1))
                    vec2 = np.append([ii+1,j+1,k+1],P[:,:,ii,j,k].reshape(-1))
                    csv_write1.writerow(vec1)
                    csv_write2.writerow(vec2)
    
out3 = open('reference_hy_F.csv','a',newline='')
out4 = open('reference_hy_P.csv','a',newline='')

csv_write3 = csv.writer(out3,dialect='excel')
csv_write4 = csv.writer(out4,dialect='excel')

for i in range(0,ninc):
    vec3 = np.append([i+1],F_record[i,:])
    vec4 = np.append([i+1],P_record[i,:])
    csv_write3.writerow(vec3)
    csv_write4.writerow(vec4)
           
print('over')
