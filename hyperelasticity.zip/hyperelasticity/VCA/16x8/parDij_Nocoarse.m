% ��Ҫ�����element_x,index
% �������޴�����
function [cluster_fxxxx,cluster_fxxxy,cluster_fxxxz,cluster_fxxyy,cluster_fxxyz,cluster_fxxzz,cluster_fyyxz,cluster_fyyyx,cluster_fyyyy,cluster_fyyyz,cluster_fyyzz,cluster_fzzxy,cluster_fzzzx,cluster_fzzzy,cluster_fzzzz] = parDij_Nocoarse(element_x,index)
global N1 N2 N3 d1 d2 
element_edge = 1;
d = d1 + d2;
num_element = N1 * N2 * N3;
tic
% ��һ���֣�׼���׶�
data_fxxxx=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fyyyy=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fzzzz=zeros(2*N1-1,2*N2-1,2*N3-1);

data_fxxxy=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fxxxz=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fyyyx=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fyyyz=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fzzzx=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fzzzy=zeros(2*N1-1,2*N2-1,2*N3-1);

data_fxxyy=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fxxzz=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fyyzz=zeros(2*N1-1,2*N2-1,2*N3-1);

data_fxxyz=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fyyxz=zeros(2*N1-1,2*N2-1,2*N3-1);
data_fzzxy=zeros(2*N1-1,2*N2-1,2*N3-1);

for inum = 1:2*N1-1
    for jnum = 1:2*N2-1
        for knum = 1:2*N3-1
            x_limt  = element_edge * (inum-1:inum);
            y_limt  = element_edge * (jnum-1:jnum);
            z_limt  = element_edge * (knum-1:knum);
            tx_limt = element_edge * (N1-1:N1);
            ty_limt = element_edge * (N2-1:N2);
            tz_limt = element_edge * (N3-1:N3);
            [xlim,ylim,zlim,txlim,tylim,tzlim] = ...
                dealSingularity(x_limt,y_limt,z_limt,tx_limt,ty_limt,tz_limt);
            data_fxxxx(inum,jnum,knum)=fxxxx(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fyyyy(inum,jnum,knum)=fyyyy(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fzzzz(inum,jnum,knum)=fzzzz(xlim,ylim,zlim,txlim,tylim,tzlim);
            
            data_fxxxy(inum,jnum,knum)=fxxxy(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fxxxz(inum,jnum,knum)=fxxxz(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fyyyx(inum,jnum,knum)=fyyyx(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fyyyz(inum,jnum,knum)=fyyyz(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fzzzx(inum,jnum,knum)=fzzzx(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fzzzy(inum,jnum,knum)=fzzzy(xlim,ylim,zlim,txlim,tylim,tzlim);
            
            data_fxxyy(inum,jnum,knum)=fxxyy(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fxxzz(inum,jnum,knum)=fxxzz(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fyyzz(inum,jnum,knum)=fyyzz(xlim,ylim,zlim,txlim,tylim,tzlim);
            
            data_fxxyz(inum,jnum,knum)=fxxyz(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fyyxz(inum,jnum,knum)=fyyxz(xlim,ylim,zlim,txlim,tylim,tzlim);
            data_fzzxy(inum,jnum,knum)=fzzxy(xlim,ylim,zlim,txlim,tylim,tzlim);
        end
    end
end
toc
tic
% �ڶ����֣���װ
cluster_fxxxx=zeros(d,d);
cluster_fyyyy=zeros(d,d);
cluster_fzzzz=zeros(d,d);

cluster_fxxxy=zeros(d,d);
cluster_fxxxz=zeros(d,d);
cluster_fyyyx=zeros(d,d);
cluster_fyyyz=zeros(d,d);
cluster_fzzzx=zeros(d,d);
cluster_fzzzy=zeros(d,d);

cluster_fxxyy=zeros(d,d);
cluster_fxxzz=zeros(d,d);
cluster_fyyzz=zeros(d,d);

cluster_fxxyz=zeros(d,d);
cluster_fyyxz=zeros(d,d);
cluster_fzzxy=zeros(d,d);

for i = 1:num_element
    I = index(i);
    for j = 1:num_element
        J = index(j);
        pre_x = round((element_x(i,1)-element_x(j,1))/element_edge) + N1;
        pre_y = round((element_x(i,3)-element_x(j,3))/element_edge) + N2;
        pre_z = round((element_x(i,5)-element_x(j,5))/element_edge) + N3;
        
        cluster_fxxxx(I,J)=cluster_fxxxx(I,J)+data_fxxxx(pre_x,pre_y,pre_z);
        cluster_fyyyy(I,J)=cluster_fyyyy(I,J)+data_fyyyy(pre_x,pre_y,pre_z);
        cluster_fzzzz(I,J)=cluster_fzzzz(I,J)+data_fzzzz(pre_x,pre_y,pre_z);
        
        cluster_fxxxy(I,J)=cluster_fxxxy(I,J)+data_fxxxy(pre_x,pre_y,pre_z);
        cluster_fxxxz(I,J)=cluster_fxxxz(I,J)+data_fxxxz(pre_x,pre_y,pre_z);
        cluster_fyyyx(I,J)=cluster_fyyyx(I,J)+data_fyyyx(pre_x,pre_y,pre_z);
        cluster_fyyyz(I,J)=cluster_fyyyz(I,J)+data_fyyyz(pre_x,pre_y,pre_z);
        cluster_fzzzy(I,J)=cluster_fzzzy(I,J)+data_fzzzy(pre_x,pre_y,pre_z);
        cluster_fzzzx(I,J)=cluster_fzzzx(I,J)+data_fzzzx(pre_x,pre_y,pre_z);
        
        cluster_fxxyy(I,J)=cluster_fxxyy(I,J)+data_fxxyy(pre_x,pre_y,pre_z);
        cluster_fxxzz(I,J)=cluster_fxxzz(I,J)+data_fxxzz(pre_x,pre_y,pre_z);
        cluster_fyyzz(I,J)=cluster_fyyzz(I,J)+data_fyyzz(pre_x,pre_y,pre_z);
        
        cluster_fxxyz(I,J)=cluster_fxxyz(I,J)+data_fxxyz(pre_x,pre_y,pre_z);
        cluster_fyyxz(I,J)=cluster_fyyxz(I,J)+data_fyyxz(pre_x,pre_y,pre_z);
        cluster_fzzxy(I,J)=cluster_fzzxy(I,J)+data_fzzxy(pre_x,pre_y,pre_z);
    end
end
toc
            