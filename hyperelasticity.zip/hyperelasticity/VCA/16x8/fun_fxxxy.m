function [ f ] = fun_fxxxy( x,y,z,tx,ty,tz )
%UNTITLED11 �˴���ʾ�йش˺�����ժҪ
%   fxxxy���Ͳ�������
dx=x-tx;
dy=y-ty;
dz=z-tz;

% f=1/72*(-((15*dx^3*dy)/sqrt(dx^2+dy^2+dz^2))-(6*dx*dy^3)/sqrt(dx^2+dy^2+dz^2)+(9*dx*dy*dz^2)/sqrt(dx^2+dy^2+dz^2)-30*dx*dy*sqrt(dx^2+dy^2+dz^2)-(24*dx^3*dz*(-((dy*dz)/(dx^2+dy^2+dz^2)^(3/2))-(dy*dz)/(dx^2*sqrt(dx^2+dy^2+dz^2))))/(1+(dy^2*dz^2)/(dx^2*(dx^2+dy^2+dz^2)))-(9*dx^5)/(sqrt(dx^2+dy^2+dz^2)*(dy+sqrt(dx^2+dy^2+dz^2)))+(18*dx^3*dz^2)/(sqrt(dx^2+dy^2+dz^2)*(dy+sqrt(dx^2+dy^2+dz^2)))+(3*dx*dz^4)/(sqrt(dx^2+dy^2+dz^2)*(dy+sqrt(dx^2+dy^2+dz^2)))+(36*dx^3*dy*dz)/(sqrt(dx^2+dy^2+dz^2)*(dz+sqrt(dx^2+dy^2+dz^2)))+(12*dx*dy^3*dz)/(sqrt(dx^2+dy^2+dz^2)*(dz+sqrt(dx^2+dy^2+dz^2)))-72*dx^2*dz*atan((dy*dz)/(dx*sqrt(dx^2+dy^2+dz^2)))-36*dx^3*log(dy+sqrt(dx^2+dy^2+dz^2))+36*dx*dz^2*log(dy+sqrt(dx^2+dy^2+dz^2))+72*dx*dy*dz*log(dz+sqrt(dx^2+dy^2+dz^2)));

f = 1/4*( -2*dx*dy*sqrt(dx^2+dy^2+dz^2) + dx*(dx^2+dy^2+dz^2)*log(dy/sqrt(dx^2+dy^2+dz^2)+1) ...
    - dx*(dx^2+dy^2+dz^2)*log(1-dy/sqrt(dx^2+dy^2+dz^2)) + dx*dy^2*log(sqrt(dx^2+dy^2+dz^2)-dy) ...
    - dx*dy^2*log(sqrt(dx^2+dy^2+dz^2)+dy) + 4*dx*dy*dz*log(sqrt(dx^2+dy^2+dz^2)+dz) ...
    - 4*dx^2*dz*atan((dy*dz)/(dx*sqrt(dx^2+dy^2+dz^2))) - 2*dx^3*log(abs((dy+sqrt(dx^2+dy^2+dz^2))/(dy-sqrt(dx^2+dy^2+dz^2)))));

end

