pretensor;
areas_all = sum(areas);
% ��para����¼����cluster�Ĳ���
d = d1 + d2;
para = zeros(d,2);
for i = 1:d
    if i <=  d1
        para(i,:) = [K1,mu1];
    else
        para(i,:) = [K2,mu2];
    end
end

% ��ʼ��
F = zeros(3,3,d);        % d��ʾ�ڼ���cluster�ı����ݶ�
for i = 1:d
    F(:,:,i) = eye(3,3);
end 
P = zeros(3,3,d);  
F0 = eye(3,3);       % ��ÿһʱ�䲽����δ֪��

% ��ʼ����ģ��������ͼ��ӣ�������ģ��
K4 = zeros(3,3,3,3,d);
C0_ = lambda0 * II + 2 * mu0 * I4s ;
C0 = matrix4_matrix2(C0_);

F_bar = zeros(ninc,9); P_bar = zeros(ninc,9);
for xx = 1:ninc             
    disp(['xx=',num2str(xx)]);
    barF = eye(3,3);  
    barF(1,1) = barF(1,1)+ xx/ninc * epsilon_max;
    barF(2,2) = barF(2,2) + xx/ninc * epsilon_max;
    % ÿ��cluster�ĳ�ʼ�� 
    F(1,1,:) = F(1,1,:) + 1/ninc * epsilon_max;
    F(2,2,:) = F(2,2,:) + 1/ninc * epsilon_max;
    step = 1;
    while true
        disp(['step=',num2str(step)]);
        step = step + 1;
        A = zeros(9*d+9,9*d+9);  % ��������ģ��
        P_C0 = zeros(9,d);           % �洢 Pj - C0:(Fj-I2)
        K_C0 = zeros(9,9,d);         % �洢 K4 - C0
        
        sum_1 = zeros(9*d,1);  % ����ʩ�¸񷽳̵�ʣ�ಿ�ֵĳ�ʼ��
        sum_2 = zeros(9,1);    % ���Ȼ�������ʣ�ಿ�ֵĳ�ʼ��
        
        % ------------------------------------------------------------------       
        for k = 1:d
            [P(:,:,k),K4(:,:,:,:,k)] = constitutive(F(:,:,k),para(k,1), para(k,2));
            P_C0(:,k) = matrix2_vector(P(:,:,k)) - C0 * ( matrix2_vector(F(:,:,k)) - matrix2_vector(I));
            K_C0(:,:,k) = matrix4_matrix2(K4(:,:,:,:,k)) - C0;            
        end
        
        % F �ķ���
        for i = 1:d
            A((i*9-8):(i*9),(i*9-8):(i*9)) = A((i*9-8):(i*9),(i*9-8):(i*9)) + eye(9,9); % FI �ĵ���
            A((i*9-8):(i*9),(d*9+1):(d*9+9)) = A((i*9-8):(i*9),(d*9+1):(d*9+9)) - eye(9,9); % -F0�ĵ���
            % ����ʩ�¸񷽳̵�ʣ�ಿ�ֺ͵�������
            sum_1((i*9-8):(i*9),1) = matrix2_vector(F(:,:,i)) - matrix2_vector(F0);
            for kk = 1:d
                sum_1((i*9-8):(i*9),1) = sum_1((i*9-8):(i*9),1) + D(:,:,i,kk) * P_C0(:,kk);
                A((i*9-8):(i*9),(kk*9-8):(kk*9)) =  A((i*9-8):(i*9),(kk*9-8):(kk*9)) + D(:,:,i,kk) * K_C0(:,:,kk);
            end
            sum_2(1,1) = sum_2(1,1) + areas(i)/ areas_all * F(1,1,i) ;
            sum_2(2,1) = sum_2(2,1) + areas(i)/ areas_all * F(2,1,i) ;
            sum_2(3,1) = sum_2(3,1) + areas(i)/ areas_all * F(3,1,i) ;
            sum_2(4,1) = sum_2(4,1) + areas(i)/ areas_all * F(1,2,i) ;
            sum_2(5,1) = sum_2(5,1) + areas(i)/ areas_all * F(2,2,i) ;
            sum_2(6,1) = sum_2(6,1) + areas(i)/ areas_all * F(3,2,i) ;
            sum_2(7,1) = sum_2(7,1) + areas(i)/ areas_all * F(1,3,i) ;
            sum_2(8,1) = sum_2(8,1) + areas(i)/ areas_all * F(2,3,i) ;
            sum_2(9,1) = sum_2(9,1) + areas(i)/ areas_all * F(3,3,i) ;
            A((9*d+1):(9*d+9),(i*9-8):(i*9)) = A((9*d+1):(9*d+9),(i*9-8):(i*9)) + areas(i)/areas_all * eye(9,9);
        end
        sum_2 = sum_2 - matrix2_vector(barF);
        sum_all = [sum_1; sum_2];
        
        dfm = - inv(A) * sum_all ;
        
        if max(abs(dfm)) < 1e-7 && max(abs(sum_2)) < 1e-7
            break;
        end
        F = F + vector_matrix3( dfm(1:(d*9),1),d );
        F0 = F0 + vector_matrix2( dfm((d*9+1):(d*9+9),1) );
    end
    
    [P_hom, F_hom] = homogenization(P,F,areas);
    F_bar(xx,:) = reshape( F_hom, 1, 9);
    P_bar(xx,:) = reshape( P_hom, 1, 9);  

end

        
        







