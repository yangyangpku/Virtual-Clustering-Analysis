function [P,K4] = constitutive(F,K,mu)
% ����(����Բ)�ı�����ϵ
global I I4rt I4s II
C4 = K * II + 2 * mu * (I4s - 1./3. * II);
Green = 0.5* (dot22( F', F) - I);
% % K1 = 50 * K; mu1 = 50 * mu;  % ѹ������
% % for i=1:3
% %     if Green(i,i) < 0
% %         C4(:,:,i,i) = K1 * II(:,:,i,i) + 2 *mu1*(I4s(:,:,i,i) - 1./3. * II(:,:,i,i));
% %     end    
% % end
S = ddot42(C4, Green);
P = dot22(F,S);
% KK4 = dot24(S,I4) + ddot44( ddot44(I4rt, dot42(dot24(F,C4),F')), I4rt);
% K4 = ddot44( ddot44(I4rt,KK4), I4rt);
K4 = ddot44(I4rt,dot24(S,I4rt)) + ddot44( dot42( dot24(F,C4),F'),I4rt);
end