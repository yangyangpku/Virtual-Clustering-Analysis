function [ f ] = fun_fxxyy( x,y,z,tx,ty,tz )
%UNTITLED11 �˴���ʾ�йش˺�����ժҪ
%   fxxyy���Ͳ�������
dx=x-tx;
dy=y-ty;
dz=z-tz;

% f=1/72*(-((15*dx^2*dy^2)/sqrt(dx^2+dy^2+dz^2))-(6*dy^4)/sqrt(dx^2+dy^2+dz^2)+(9*dy^2*dz^2)/sqrt(dx^2+dy^2+dz^2)-15*dx^2*sqrt(dx^2+dy^2+dz^2)-18*dy^2*sqrt(dx^2+dy^2+dz^2)+9*dz^2*sqrt(dx^2+dy^2+dz^2)-(24*dx^3*dz*(-((dy^2*dz)/(dx*(dx^2+dy^2+dz^2)^(3/2)))+dz/(dx*sqrt(dx^2+dy^2+dz^2))))/(1+(dy^2*dz^2)/(dx^2*(dx^2+dy^2+dz^2)))-(9*dx^4*(1+dy/sqrt(dx^2+dy^2+dz^2)))/(dy+sqrt(dx^2+dy^2+dz^2))+(18*dx^2*dz^2*(1+dy/sqrt(dx^2+dy^2+dz^2)))/(dy+sqrt(dx^2+dy^2+dz^2))+(3*dz^4*(1+dy/sqrt(dx^2+dy^2+dz^2)))/(dy+sqrt(dx^2+dy^2+dz^2))+(36*dx^2*dy^2*dz)/(sqrt(dx^2+dy^2+dz^2)*(dz+sqrt(dx^2+dy^2+dz^2)))+(12*dy^4*dz)/(sqrt(dx^2+dy^2+dz^2)*(dz+sqrt(dx^2+dy^2+dz^2)))+36*dx^2*dz*log(dz+sqrt(dx^2+dy^2+dz^2))+36*dy^2*dz*log(dz+sqrt(dx^2+dy^2+dz^2)));

f = 1/6*( (-2*dx^2 - 2*dy^2 + dz^2)*sqrt(dx^2+dy^2+dz^2) + 3*dz*(dx^2+dy^2)*log(sqrt(dx^2+dy^2+dz^2)+dz) );

end

