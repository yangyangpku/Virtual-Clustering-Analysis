function [k1,k2] = data_select(N1,N2,N3,radius2)
center1 = (N1 + 1) /2;
center2 = (N2 + 1) /2;
center3 = (N3 + 1) /2;
A = csvread('cluster_ep_F.csv');
disp('���ݶ�ȡ��ϣ�');
len = length(A); 
k1 = [];  k2 = [];
for i = 1:len
    distance = ( A(i,1)-center1 )^2 + ( A(i,2) - center2)^2 + ( A(i,3) - center3)^2;
    if distance > radius2
        k1 = [k1; A(i,:)];
    else 
        k2 = [k2; A(i,:)];
    end
end
        
        

        
        