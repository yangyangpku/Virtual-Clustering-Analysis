function [ f ] = fun_fxxyz( x,y,z,tx,ty,tz )
%UNTITLED11 �˴���ʾ�йش˺�����ժҪ
%   fxxyz���Ͳ�������
dx=x-tx;
dy=y-ty;
dz=z-tz;

% f=1/72*(-((15*dx^2*dy*dz)/sqrt(dx^2+dy^2+dz^2))-(6*dy^3*dz)/sqrt(dx^2+dy^2+dz^2)+(9*dy*dz^3)/sqrt(dx^2+dy^2+dz^2)+18*dy*dz*sqrt(dx^2+dy^2+dz^2)-(24*dx^3*dz*(-((dy*dz^2)/(dx*(dx^2+dy^2+dz^2)^(3/2)))+dy/(dx*sqrt(dx^2+dy^2+dz^2))))/(1+(dy^2*dz^2)/(dx^2*(dx^2+dy^2+dz^2)))-(9*dx^4*dz)/(sqrt(dx^2+dy^2+dz^2)*(dy+sqrt(dx^2+dy^2+dz^2)))+(18*dx^2*dz^3)/(sqrt(dx^2+dy^2+dz^2)*(dy+sqrt(dx^2+dy^2+dz^2)))+(3*dz^5)/(sqrt(dx^2+dy^2+dz^2)*(dy+sqrt(dx^2+dy^2+dz^2)))+(36*dx^2*dy*dz*(1+dz/sqrt(dx^2+dy^2+dz^2)))/(dz+sqrt(dx^2+dy^2+dz^2))+(12*dy^3*dz*(1+dz/sqrt(dx^2+dy^2+dz^2)))/(dz+sqrt(dx^2+dy^2+dz^2))-24*dx^3*atan((dy*dz)/(dx*sqrt(dx^2+dy^2+dz^2)))+36*dx^2*dz*log(dy+sqrt(dx^2+dy^2+dz^2))+12*dz^3*log(dy+sqrt(dx^2+dy^2+dz^2))+36*dx^2*dy*log(dz+sqrt(dx^2+dy^2+dz^2))+12*dy^3*log(dz+sqrt(dx^2+dy^2+dz^2)));

f = 1/12*( 4*dy*dz*sqrt(dx^2+dy^2+dz^2) + 6*dx^2*dz*log(sqrt(dx^2+dy^2+dz^2)+dy) + 6*dx^2*dy*log(sqrt(dx^2+dy^2+dz^2)+dz)...
    + 2*dz^3*log(sqrt(dx^2+dy^2+dz^2)+dy) + 2*dy^3*log(sqrt(dx^2+dy^2+dz^2)+dz) ...
    - 3*dx^2*dy*log(dx^2+dy^2) - 3*dx^2*dz*log(dx^2+dz^2) - dy^3*log(dx^2+dy^2) - dz^3*log(dx^2+dz^2)...
    - 4*dx^3*atan((dy*dz)/(dx*sqrt(dx^2+dy^2+dz^2))) );

end

