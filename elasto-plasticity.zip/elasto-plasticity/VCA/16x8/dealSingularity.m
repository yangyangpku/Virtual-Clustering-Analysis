function [xlim,ylim,zlim,txlim,tylim,tzlim] = dealSingularity( xlim,ylim,zlim,txlim,tylim,tzlim )
%UNTITLED18 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
delta=2.5*10^(-6);
for x_j=1:2
    for tx_j=1:2
        if abs(xlim(x_j)-txlim(tx_j))<10^(-9)
            txlim(tx_j)=txlim(tx_j)+delta;
        end
    end
end
for x_j=1:2
    for tx_j=1:2
        if abs(ylim(x_j)-tylim(tx_j))<10^(-9)
            tylim(tx_j)=tylim(tx_j)+delta;
        end
    end
end
for x_j=1:2
    for tx_j=1:2
        if abs(zlim(x_j)-tzlim(tx_j))<10^(-9)
            tzlim(tx_j)=tzlim(tx_j)+delta;
        end
    end
end
end

