function [kk1,s1] = areasSegmentation(kk1,s1)
[len,~] = size(kk1);
row = find(s1==0);     % row = [1,4,6]
[~,col] = size(row);   % col = 3
if col ~= 0
    disp([num2str(col),' areas have(has) an area of 0 ']);
    [~,index] = sort(s1,'descend');
    counter = ones(1,col);   % ������
    for i = 1:len
        for j = 1:col
            if kk1(i,1) == index(j) 
                if mod(counter(j),2) == 0
                   kk1(i,1) = row(j);
                   s1( index(j) ) = s1( index(j) ) - 1;
                   s1( row(j) )   = s1( row(j) )  + 1;
                end
                counter(j) = counter(j) + 1;
                break;
            end
        end
    end
end
                
            
        
    
