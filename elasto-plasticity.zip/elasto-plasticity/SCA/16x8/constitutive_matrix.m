function [P,K4,be,ep] = constitutive_matrix(F, F_t, be_t, ep_t)
 
global I I4 I4rt I4s II K1 mu1 tauy1 H1

C4e = K1 * II + 2 * mu1 * (I4s - 1./3. * II);       
% trial state
Fdelta = dot22(F,inv(F_t)); 
be_s = dot22(Fdelta,dot22(be_t, Fdelta')); 
lnbe_s = ln2(be_s); 
tau_s = ddot42(C4e, lnbe_s)/2.0; 
taum_s = ddot22(tau_s,I)/3.0; 
taud_s = tau_s - taum_s * I; 
taueq_s = sqrt(3./2. * ddot22(taud_s,taud_s)); 
N_s = 3./2. * taud_s / taueq_s; 
phi_s = taueq_s - (tauy1 + H1 * ep_t);     
phi_s = 1./2. * ( phi_s + abs(phi_s));  

% return map
dgamma = phi_s / (H1 + 3. * mu1); 
ep = ep_t + dgamma;
tau = tau_s - 2. * dgamma * N_s * mu1;
lnbe = lnbe_s - 2. * dgamma * N_s;
be = exp2(lnbe);
P = dot22(tau, (inv(F))');

% consistent tangent operator
a0 = dgamma * mu1 / taueq_s;
a1 = mu1 / (H1 + 3. * mu1);
C4ep = ( (K1-2./3.*mu1)/2.+a0*mu1 )* II + (1. -3.*a0)*mu1*I4s + 2.*mu1*(a0-a1)*dyad22(N_s,N_s);
dlnbe4_s = dln2_d2(be_s);    %%%%%%%%%%%%%%% ����dln2_d2
dbe4_s = 2. * dot42(I4s,be_s);
K4 = (C4e/2.0)*(phi_s <=0.) + C4ep*(phi_s>0.);
K4 = ddot44(K4, ddot44(dlnbe4_s,dbe4_s));
K4 = dot42(-I4,tau) + K4;
% K4 = dot42(dot24(inv(F),K4),(inv(F))');
K4 = ddot44(I4rt,dot42(dot24(inv(F),K4),(inv(F))'));
end

function [K4]=dln2_d2(x)
% �˴��й��޸�
[vals,vecs] = eig2(x);
K4 = zeros(3,3,3,3);
for i=1:3
    for j=1:3
        if vals(i) == vals(j)
            gc = 1.0 / vals(i);
        else
            gc = ( log(vals(j)) - log(vals(i)) ) / ( vals(j) - vals(i) );
        end
        K4 = K4 + gc * dyad22( dyad11(vecs(:,j), vecs(:,i)), dyad11(vecs(:,j),vecs(:,i)));
    end
end
end

            












