function [P,K4] = constitutive_inclusion(F)
global I I4rt I4s II K2 mu2
C4 = K2 * II + 2 * mu2 * (I4s - 1./3. * II);
Green = 0.5* (dot22( F', F) - I);
S = ddot42(C4, Green);
P = dot22(F,S);
K4 = ddot44(I4rt,dot24(S,I4rt)) + ddot44( dot42( dot24(F,C4),F'),I4rt);
end