function [z] = exp2(x)
[vals, vecs] = eig2(x);
z = zeros(3,3);
for i=1:3
    z = z + exp(vals(i)) * dyad11(vecs(:,i),vecs(:,i));
end
