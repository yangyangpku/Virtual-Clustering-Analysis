function [D] = generateDij(areas,cluster_fxxxx,cluster_fxxxy,cluster_fxxxz,cluster_fxxyy,cluster_fxxyz,cluster_fxxzz,cluster_fyyxz,cluster_fyyyx,cluster_fyyyy,cluster_fyyyz,cluster_fyyzz,cluster_fzzxy,cluster_fzzzx,cluster_fzzzy,cluster_fzzzz)
global lambda0 mu0 d
s = (lambda0 + mu0)/ mu0;
phi0 = 1/mu0/(1+s);

D = zeros(9,9,d,d);
for i = 1:d
    for j = 1:d
        D(1,1,i,j)=cluster_fxxxx(i,j) + (s+1) * ( cluster_fxxyy(i,j) + cluster_fxxzz(i,j) );
        D(1,2,i,j)=-s * cluster_fxxxy(i,j);
        D(1,3,i,j)=-s * cluster_fxxxz(i,j);
        D(1,4,i,j)=cluster_fxxxy(i,j) + (s+1) * ( cluster_fyyyx(i,j) + cluster_fzzxy(i,j) );
        D(1,5,i,j)=-s * cluster_fxxyy(i,j);
        D(1,6,i,j)=-s * cluster_fxxyz(i,j);
        D(1,7,i,j)=cluster_fxxxz(i,j) + (s+1) * ( cluster_fyyxz(i,j) + cluster_fzzzx(i,j) );
        D(1,8,i,j)=-s * cluster_fxxyz(i,j);
        D(1,9,i,j)=-s * cluster_fxxzz(i,j);
%         D(i,j,2,1)=-s * cluster_fxxxy(i,j);
        D(2,2,i,j)=cluster_fxxyy(i,j) + (s+1) * ( cluster_fxxxx(i,j) + cluster_fxxzz(i,j) );
        D(2,3,i,j)=-s * cluster_fxxyz(i,j);
        D(2,4,i,j)=-s * cluster_fxxyy(i,j);
        D(2,5,i,j)=cluster_fyyyx(i,j) + (s+1) * ( cluster_fxxxy(i,j) + cluster_fzzxy(i,j) );
        D(2,6,i,j)=-s * cluster_fyyxz(i,j);
        D(2,7,i,j)=-s * cluster_fxxyz(i,j);
        D(2,8,i,j)=cluster_fyyxz(i,j) + (s+1) * ( cluster_fxxxz(i,j) + cluster_fzzzx(i,j) );
        D(2,9,i,j)=-s * cluster_fzzxy(i,j); 
%         D(i,j,3,1)=-s * cluster_fxxxz(i,j);
%         D(i,j,3,2)=-s * cluster_fxxyz(i,j);
        D(3,3,i,j)=cluster_fxxzz(i,j) + (s+1) * ( cluster_fxxxx(i,j) + cluster_fxxyy(i,j) );
        D(3,4,i,j)=-s * cluster_fxxyz(i,j);
        D(3,5,i,j)=-s * cluster_fyyxz(i,j);
        D(3,6,i,j)=cluster_fzzxy(i,j) + (s+1) * ( cluster_fxxxy(i,j) + cluster_fyyyx(i,j) );
        D(3,7,i,j)=-s * cluster_fxxzz(i,j);
        D(3,8,i,j)=-s * cluster_fzzxy(i,j);
        D(3,9,i,j)=cluster_fzzzx(i,j) + (s+1) * ( cluster_fxxxz(i,j) + cluster_fyyxz(i,j) );
        D(4,4,i,j)=cluster_fxxyy(i,j) + (s+1) * ( cluster_fyyyy(i,j) + cluster_fyyzz(i,j) );
        D(4,5,i,j)=-s * cluster_fyyyx(i,j);
        D(4,6,i,j)=-s * cluster_fyyxz(i,j);
        D(4,7,i,j)=cluster_fxxyz(i,j) + (s+1) * ( cluster_fyyyz(i,j) + cluster_fzzzy(i,j) );
        D(4,8,i,j)=-s * cluster_fyyxz(i,j);
        D(4,9,i,j)=-s * cluster_fzzxy(i,j);
        D(5,5,i,j)=cluster_fyyyy(i,j) + (s+1) * ( cluster_fxxyy(i,j) + cluster_fyyzz(i,j) );
        D(5,6,i,j)=-s * cluster_fyyyz(i,j);
        D(5,7,i,j)=-s * cluster_fyyxz(i,j);   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        D(5,8,i,j)=cluster_fyyyz(i,j) + (s+1) * ( cluster_fxxyz(i,j) + cluster_fzzzy(i,j) );
        D(5,9,i,j)=-s * cluster_fyyzz(i,j);
        D(6,6,i,j)=cluster_fyyzz(i,j) + (s+1) * ( cluster_fxxyy(i,j) + cluster_fyyyy(i,j) );
        D(6,7,i,j)=-s * cluster_fzzxy(i,j);
        D(6,8,i,j)=-s * cluster_fyyzz(i,j);
        D(6,9,i,j)=cluster_fzzzy(i,j) + (s+1) * ( cluster_fxxyz(i,j) + cluster_fyyyz(i,j) );
        D(7,7,i,j)=cluster_fxxzz(i,j) + (s+1) * ( cluster_fyyzz(i,j) + cluster_fzzzz(i,j) );
        D(7,8,i,j)=-s * cluster_fzzxy(i,j);
        D(7,9,i,j)=-s * cluster_fzzzx(i,j);
        D(8,8,i,j)=cluster_fyyzz(i,j) + (s+1) * ( cluster_fxxzz(i,j) + cluster_fzzzz(i,j) );
        D(8,9,i,j)=-s * cluster_fzzzy(i,j);
        D(9,9,i,j)=cluster_fzzzz(i,j) + (s+1) * ( cluster_fxxzz(i,j) + cluster_fyyzz(i,j) );
        for k=2:9
            for l=1:(k-1)
                D(k,l,i,j) = D(l,k,i,j);
            end
        end
        D(:,:,i,j) = D(:,:,i,j) * phi0 /8/pi;
        D(:,:,i,j) = D(:,:,i,j) / areas(i);
    end
end