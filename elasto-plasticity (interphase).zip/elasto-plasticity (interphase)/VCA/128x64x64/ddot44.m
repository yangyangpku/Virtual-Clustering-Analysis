function [z] = ddot44(x,y)
% �Ľ�����x���Ľ�����y��˫���
z = zeros(3,3,3,3);
for i = 1:3
    for j = 1:3
        for k = 1:3
            for m = 1:3
                for n = 1:3
                    for p = 1:3
                        z(i,j,k,m) = z(i,j,k,m) + x(i,j,n,p) * y(n,p,k,m);
                    end
                end
            end
        end
    end
end
