function [P_hom, F_hom] = homogenization(P,F)
global areas
len = length(areas);
areas_all = sum(areas);
F_hom = zeros(3,3); P_hom = zeros(3,3);
for i = 1: len
    F_hom = F_hom + areas(i)/areas_all * F(:,:,i) ;   
    P_hom = P_hom + areas(i)/areas_all * P(:,:,i);    
end
