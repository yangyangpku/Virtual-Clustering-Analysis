function [k1,k2,k3] = data_select(radius1,radius2)
global N1 N2 N3
center1 = (N1 + 1) /2;
center2 = (N2 + 1) /2;
center3 = (N3 + 1) /2;
A   = csvread('cluster_cold_F.csv');
disp('���ݶ�ȡ��ϣ�');
len = length(A); 
% k1 ���壻 k2 �м�㣻 k3 ���ӣ�
k1 = [];  k2 = [];  k3 = []; 
for i = 1:len
    distance = ( A(i,1)-center1 )^2 + ( A(i,2) - center2)^2 + ( A(i,3) - center3)^2;
    if distance <= radius2
        if distance > radius1 
            k2 = [k2; A(i,:)];
        else
            k3 = [k3; A(i,:)];
        end
    else
        k1 = [k1; A(i,:)];
    end
end
        
        

        
        