pretensor;
areas_all = sum(areas);

% ��para����¼����cluster�Ĳ���
global K mu
K = zeros(d,1); mu = zeros(d,1);
for i = 1:d
    if i <= d1
        K(i) = K1; mu(i) = mu1;
    elseif i <= (d1+d2)
        K(i) = K3; mu(i) = mu3;
    else
        K(i) = K2; mu(i) = mu2;
    end
end

% ��ʼ��1.(a)
F = zeros(3,3,d); 
for i = 1:d
    F(:,:,i) = eye(3,3);
end
F_t = F;
P = zeros(3,3,d);  P_total = zeros(3,3,d); 
% P0 = zeros(7,1); P0_t = zeros(7,1); % ����
ep_t = zeros(d,1); ep = zeros(d,1); ep_new = ep;
be_t = F; be = F; be_new = F; 
% crack_indicator = zeros(d,1); crack_indicator_new = zeros(d,1); crack_indicator_new1 = zeros(d,1); flag = zeros(d,1);
dF = zeros(3,3,d);
% F0 = eye(3,3);
F_bar = eye(3,3); F_bart = eye(3,3);
% end_indicator = 0;
% ��ʼ��1.(b)
% ��ʼ������cluster�����߸նȣ�����ʼ���ο����ϵĸն�C0
K4 = zeros(3,3,3,3,d); 
C0_ = zeros(3,3,3,3);
for i = 1:d
    K4(:,:,:,:,i) = K(i,1) * II + 2 * mu(i,1) * (I4s - 1./3. * II); 
    C0_ = C0_ + areas(i) / areas_all * K4(:,:,:,:,i);
end
C0 = matrix4_matrix2(C0_);
% ��ʼ���ο����ϵ�lame����
J = 1/3 * II; KK = I4 - J;
C_J = C0 .* matrix4_matrix2(J) ; C_K = C0 .* matrix4_matrix2(KK);
lambda0 = 1/3 * ( sum( C_J(:) ) - 1/8 * sum( C_K(:) ) );
mu0 = 1/16 * sum( C_K(:) );

lambdaSet = zeros(ninc,1); muSet = zeros(ninc,1);
F_com = zeros(ninc,9); P_com = zeros(ninc,9); % ���Դ洢�������F��P
F_field = zeros(3,3,d,ninc); P_field = zeros(3,3,d,ninc);
ep_num = zeros(ninc,2);
for xx = 1:ninc
    disp(['xx=====',num2str(xx)]);
    F_bar(1,1) = F_bar(1,1) - 1/ninc * epsilon_max_xx;
    F_bar(2,2) = F_bar(2,2) - 1/ninc * epsilon_max_yy;
    F_bar(3,3) = F_bar(3,3) + 1/ninc * epsilon_max_zz;
    dF_bar = F_bar - F_bart;
%     F0(1,1) = F0(1,1) - 1/ninc * epsilon_max_xx;
%     F0(2,2) = F0(2,2) - 1/ninc * epsilon_max_yy;
%     F0(3,3) = F0(3,3) + 1/ninc * epsilon_max_zz;
%     P0(1,1) = P_bar(xx,4); P0(2,1) = P_bar(xx,7); P0(3,1) = P_bar(xx,2); % P_bar���ݺ�������
%     P0(4,1) = P_bar(xx,8); P0(5,1) = P_bar(xx,3); P0(6,1) = P_bar(xx,6); P0(7,1) = P_bar(xx,9);
%     dP0 = P0 - P0_t;
    % ÿ��cluster��dF��ʼ�� 
%     dF0 = F0 - F0_t;
    for yy = 1:d
        dF(:,:,yy) = dF_bar;
    end
%     crack_step_xx = 1; 
%     len_t = 0;
    while true
        % ��������
        
        F_new = F + dF; 
        dF_new = dF;
        dF0_new = dF_bar;
%         be_new = be;
%         ep_new = ep;
        D = 1/2/mu0 * D1 -  lambda0/2/mu0/(lambda0+2*mu0) * D2;
        C0_ = lambda0 * II + 2 * mu0 * I4 ;
        C0 = matrix4_matrix2(C0_);
        step = 1;
        while true
            disp(['step=',num2str(step)]);
            step = step + 1;
            A = zeros(9*d+9,9*d+9);  % ����ģ������
            P_C0 = zeros(9,d);           % �洢 dPj - C0:dFj
            K_C0 = zeros(9,9,d);         % �洢 K4 - C0
            
            r1 = zeros(9*d,1);     % ������������ʩ�¸񷽳̵�ʣ�ಿ�ֵĳ�ʼ��
            r2 = zeros(9,1);
            
            dP_new = zeros(3,3,d);   
            for k = 1:d
                [P_total(:,:,k), K4(:,:,:,:,k), be_new(:,:,k), ep_new(k,1)] = constitutive(F_new,F_t,be_t,ep_t,k);
                dP_new(:,:,k) = P_total(:,:,k) - P(:,:,k); 
                P_C0(:,k) = matrix2_vector(dP_new(:,:,k)) - C0 *  matrix2_vector(dF_new(:,:,k));  
                K_C0(:,:,k) = matrix4_matrix2(K4(:,:,:,:,k)) - C0;
               
            end
            
            
            %     F �ķ���
            for i = 1:d
                A((i*9-8):(i*9),(i*9-8):(i*9)) = A((i*9-8):(i*9),(i*9-8):(i*9)) + eye(9,9); % ����FI �ĵ���
                A((i*9-8):(i*9),(d*9+1):(d*9+9)) = A((i*9-8):(i*9),(d*9+1):(d*9+9)) - eye(9,9); % ����F0�ĵ���
%                 A((i*9-7):(i*9-5),(d*9+1):(d*9+3)) = A((i*9-7):(i*9-5),(d*9+1):(d*9+3)) - eye(3,3);  % ����F0�ĵ���
%                 A((i*9-3):(i*9),(d*9+4):(d*9+7)) = A((i*9-3):(i*9),(d*9+4):(d*9+7)) - eye(4,4);    % ����F0�ĵ���
                % ����ʩ�¸񷽳̵�ʣ�ಿ�ֺ͵�������
                r1((i*9-8):(i*9),1) = matrix2_vector(dF_new(:,:,i)) - matrix2_vector(dF0_new);
                for kk = 1:d
                    r1((i*9-8):(i*9),1) = r1((i*9-8):(i*9),1) + D(:,:,i,kk) * P_C0(:,kk);
                    A((i*9-8):(i*9),(kk*9-8):(kk*9)) =  A((i*9-8):(i*9),(kk*9-8):(kk*9)) + D(:,:,i,kk) * K_C0(:,:,kk);
                end
                r2(1,1) = r2(1,1) + areas(i)/areas_all * dF_new(1,1,i);
                r2(2,1) = r2(2,1) + areas(i)/areas_all * dF_new(2,1,i);
                r2(3,1) = r2(3,1) + areas(i)/areas_all * dF_new(3,1,i);
                r2(4,1) = r2(4,1) + areas(i)/areas_all * dF_new(1,2,i);
                r2(5,1) = r2(5,1) + areas(i)/areas_all * dF_new(2,2,i);
                r2(6,1) = r2(6,1) + areas(i)/areas_all * dF_new(3,2,i);
                r2(7,1) = r2(7,1) + areas(i)/areas_all * dF_new(1,3,i);
                r2(8,1) = r2(8,1) + areas(i)/areas_all * dF_new(2,3,i);
                r2(9,1) = r2(9,1) + areas(i)/areas_all * dF_new(3,3,i);
                A((9*d+1):(9*d+9),(i*9-8):(i*9)) = A((9*d+1):(9*d+9),(i*9-8):(i*9)) + areas(i)/areas_all * eye(9,9);
%                 r2(1,1) = r2(1,1) + areas(i)/areas_all * dP_new(2,1,i);
%                 r2(2,1) = r2(2,1) + areas(i)/areas_all * dP_new(3,1,i);
%                 r2(3,1) = r2(3,1) + areas(i)/areas_all * dP_new(1,2,i);
%                 r2(4,1) = r2(4,1) + areas(i)/areas_all * dP_new(3,2,i);
%                 r2(5,1) = r2(5,1) + areas(i)/areas_all * dP_new(1,3,i);
%                 r2(6,1) = r2(6,1) + areas(i)/areas_all * dP_new(2,3,i);
%                 r2(7,1) = r2(7,1) + areas(i)/areas_all * dP_new(3,3,i);
%                 A((9*d+1):(9*d+7),(i*9-8):(i*9)) = A((9*d+1):(9*d+7),(i*9-8):(i*9)) + derivative(K4(:,:,:,:,i),i);
            end
            
            r2 = r2 - matrix2_vector(dF_bar);
            r = [r1;r2];
            detla_f = - inv(A) * r ;
            
%             cache1 = [0,        detla_f(d*9+3),detla_f(d*9+5);
%                 detla_f(d*9+1),        0,      detla_f(d*9+6);
%                 detla_f(d*9+2), detla_f(d*9+4),detla_f(d*9+7)];
            if max(abs(detla_f)) < 1e-8 && max(abs(r2)) < 1e-8
                break;
            end
            
            dF_new = dF_new + vector_matrix3( detla_f(1:(d*9),1) ,d);
            F_new = F + dF_new;
            dF0_new = dF0_new + vector_matrix2( detla_f((9*d+1):(9*d+9),1) );
%             dF0_new = dF0_new + cache1;
%             F0_new  = F0_t      + dF0_new;
        end
        
        % ���ж��Ѽ��
%         crack_treatment;        
%         if end_indicator == 1
%             F = F_copy;
%             P  = P_copy;
%             break;
%         end
        [lambda_opt,mu_opt] = update_incremental_lam_mu( A( 1:(9*d),1:(9*d) ),K4 );
        if abs(lambda_opt-lambda0)/lambda0 < 10^(-3) && abs(mu_opt-mu0)/mu0 < 10^(-3) 
            lambda0 = lambda_opt; mu0 = mu_opt;
            lambdaSet(xx,1) = lambda0; muSet(xx,1) = mu0;
            F = F_new;
            be = be_new;
            ep = ep_new;
            P  = P_total;
%             F0 = F0_new;
%             crack_indicator = crack_indicator_new;
                        
            break;
        else
            lambda0 = lambda_opt; mu0 = mu_opt;
            
        end
        
    end
   
    % ����ʹ�õ���homogenization_P��������homogenization
    [P_hom, F_hom] = homogenization(P,F);
    F_com(xx,:) = reshape( F_hom, 1, 9);
    P_com(xx,:) = reshape( P_hom, 1, 9);   
    
    ep_ini = 0;
    for i = 1: d1
        ep_ini = ep_ini + ( ep(i,1) > 10^(-7) ) * areas(i,1);
    end
    ep_num(xx,1) = xx; ep_num(xx,2) = ep_ini;
    F_field(:,:,:,xx) = F;  P_field(:,:,:,xx) = P; 
%     if end_indicator == 1
%         break;
%     end
%     F0_t = F0; 
%     P0_t = P0;
    F_t = F;
    be_t = be;
    ep_t = ep;
    F_bart = F_bar;
end