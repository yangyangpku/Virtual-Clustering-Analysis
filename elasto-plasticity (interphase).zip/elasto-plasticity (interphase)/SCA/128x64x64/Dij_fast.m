function [D1,D2] = Dij_fast(kk1,kk2,kk3) 
% ----------------------------------------------
global N1 N2 N3 d1 d2 d areas

N = [N1,N2,N3];

cluster_map = zeros(N1,N2,N3,d);
len1 = length(kk1); len2 = length(kk2); len3 = length(kk3);
for i = 1:len1
    cluster_map(kk1(i,2),kk1(i,3),kk1(i,4),kk1(i,1)) = 1;
end
for j = 1:len2
    cluster_map(kk2(j,2),kk2(j,3),kk2(j,4),kk2(j,1) + d1) = 1;         
end
for j = 1:len3
    cluster_map(kk3(j,2),kk3(j,3),kk3(j,4),kk3(j,1) + d1 + d2) = 1;         
end
disp('cluster_map is done!');
% -----------------------------------------------
% �໥���������ĵ�һ���ֺ͵ڶ�����(����Ҷ�任֮��Ŀռ�)
gramma_1 = zeros(N1,N2,N3,3,3,3,3);
gramma_2 = zeros(N1,N2,N3,3,3,3,3);
tic
for n = 1:N1
    n1 = n;
    if n1 > floor(N1/2+1)
        n1 = n1 - N1;
    end
    for p = 1:N2
        p1 = p;
        if p1 > floor(N2/2+1)
            p1 = p1 - N2;
        end
        for q = 1:N3
            q1 = q;
            if q1 > floor(N3/2+1)
                q1 = q1 - N3;
            end
            npq = [n1,p1,q1];
            if n == 1 && p == 1 && q == 1
                gramma_1(n,p,q,:,:,:,:) = 0;
                gramma_2(n,p,q,:,:,:,:) = 0;
                continue;
            end
            for i = 1:3
                for j = 1:3
                    for k = 1:3
                        for m = 1:3
                            gramma_1(n,p,q,i,j,k,m) = (i==k) * xi( N(j), npq(j)) * xi(N(m),npq(m)) ...
                                / (xi(N1,npq(1))^2 + xi(N2,npq(2))^2 + xi(N3,npq(3))^2);
                            gramma_2(n,p,q,i,j,k,m) = xi(N(i), npq(i)) * xi(N(j), npq(j)) * ...
                                xi(N(k), npq(k)) * xi(N(m), npq(m)) / (xi(N1,npq(1))^2 + xi(N2,npq(2))^2 + xi(N3,npq(3))^2)^2 ;
                        end
                    end
                end
            end
        end
    end
end
toc
disp('the gramma_s fourier transformation is done!');

% -----------------------------------------------------
% % ���D1��D2����Ϊdxdx3x3x3x3��������
fftn_chi_J = zeros(N1,N2,N3,d);
for i = 1:d
    fftn_chi_J(:,:,:,i) = fftn(cluster_map(:,:,:,i));
end
tic
cache1 = zeros(N1,N2,N3,d);cache2 = zeros(N1,N2,N3,d);
D1_tensor = zeros(3,3,3,3,d,d); D2_tensor = zeros(3,3,3,3,d,d);
for i = 1:3
    for j = 1:3
        for k = 1:3
            for m = 1:3
                for J = 1:d
                    cache1(:,:,:,J) = ifftn(gramma_1(:,:,:,i,j,k,m) .* fftn_chi_J(:,:,:,J));
                    cache2(:,:,:,J) = ifftn(gramma_2(:,:,:,i,j,k,m) .* fftn_chi_J(:,:,:,J));
                end
                for I = 1:d
                    for J = 1:d
                        D1_tensor(i,j,k,m,I,J) = sum( sum( sum (cluster_map(:,:,:,I) .* cache1(:,:,:,J))))/areas(I);
                        D2_tensor(i,j,k,m,I,J) = sum( sum( sum (cluster_map(:,:,:,I) .* cache2(:,:,:,J))))/areas(I);
                    end
                end
            end
        end
    end
end
toc
% ---------------------------------------------------------------
% ������D1��D2����СΪdxdx3x3x3x3��ת��Ϊ���󣨴�СΪdxdx9x9��
D1 = zeros(9,9,d,d); D2 = zeros(9,9,d,d);
for I = 1:d
    for J = 1:d
        D1(:,:,I,J) = real(matrix4_matrix2(D1_tensor(:,:,:,:,I,J)));
        D2(:,:,I,J) = real(matrix4_matrix2(D2_tensor(:,:,:,:,I,J)));
    end
end
disp('the matrix D1 and D2 are done!');
end

function [m] = xi(x,y)
m = (y-1)/x * 2 * pi;
end