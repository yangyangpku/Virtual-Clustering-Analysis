function [a] = vector_matrix3(b, d)
a = zeros(3,3,d);
for i = 1:d
    a(:,:,i) = [b(i*9-8,1),b(i*9-5,1),b(i*9-2,1);
        b(i*9-7,1),b(i*9-4,1),b(i*9-1,1);
        b(i*9-6,1),b(i*9-3,1),b(i*9,1)];
end
end