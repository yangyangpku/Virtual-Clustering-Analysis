function [P,K4,be,ep] = constitutive(F,F_t,be_t,ep_t,i)
global d1 d2
if i <=d1
    [P,K4,be,ep] = constitutive_matrix(F(:,:,i), F_t(:,:,i), be_t(:,:,i), ep_t(i));
elseif i <= (d1+d2)
    [P,K4] = constitutive_mid(F(:,:,i));
    be = be_t(:,:,i); ep = ep_t(i,1);
else
    [P,K4] = constitutive_inclusion(F(:,:,i));
    be = be_t(:,:,i); ep = ep_t(i,1);
end

